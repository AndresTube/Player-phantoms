package com.andrestube.phantoms;

import java.util.ArrayList;
import java.util.List;

import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.entity.Zombie;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.inventory.ItemStack;

public class PhantomListener implements Listener {

    private final PhantomPlugin plugin;

    public PhantomListener(PhantomPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onPlayerDeath(PlayerDeathEvent event) {
        Player player = event.getEntity();
        Location deathLoc = player.getLocation();
        
        // Capturamos los items que iban a soltarse y evitamos que caigan ahora
        List<ItemStack> drops = new ArrayList<>(event.getDrops());
        event.getDrops().clear();

        // Generamos la entidad Fantasma con la skin del jugador y registramos su loot
        Zombie phantom = PhantomEntity.spawnPhantom(plugin, player, deathLoc);
        plugin.registerPhantomLoot(phantom, drops);

        player.sendMessage("§c¡Una sombra hostil de tu yo perdido ha surgido en §e" 
                          + deathLoc.getBlockX() + ", " + deathLoc.getBlockY() + ", " + deathLoc.getBlockZ() + "!");
    }

    @EventHandler
    public void onEntityDeath(EntityDeathEvent event) {
        // Si es un phantom nuestro, sustituimos los drops por los guardados
        if (event.getEntity() == null) return;
        if (!PhantomEntity.isPhantom(event.getEntity())) return;

        List<ItemStack> loot = plugin.popPhantomLoot(event.getEntity().getUniqueId());
        if (loot == null || loot.isEmpty()) return;

        event.getDrops().clear();
        for (ItemStack item : loot) {
            if (item != null) event.getDrops().add(item);
        }
    }
}
