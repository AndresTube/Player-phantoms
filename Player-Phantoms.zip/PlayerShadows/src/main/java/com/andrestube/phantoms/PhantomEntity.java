package com.andrestube.phantoms;

import org.bukkit.Location;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance; 
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.entity.Zombie;
import org.bukkit.entity.LivingEntity;
import org.bukkit.inventory.ItemStack;
import org.bukkit.Material;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.metadata.FixedMetadataValue;

public class PhantomEntity {
    
    private static final String PHANTOM_KEY = "PlayerPhantom";
    
    public static Zombie spawnPhantom(PhantomPlugin plugin, Player originalPlayer, Location location) {
        
        Zombie phantom = (Zombie) location.getWorld().spawnEntity(location, EntityType.ZOMBIE);
        
        // --- 1. Configuración de Apariencia ---
        phantom.setCustomName("§4Sombra de §c" + originalPlayer.getName());
        phantom.setCustomNameVisible(true);
        phantom.setBaby(false);
        phantom.setSilent(true);
        
        // --- 2. Stats Mejorados (La sintaxis defensiva para evitar el error GENERIC_...) ---
        
        // 40 HP (el doble de un jugador)
    AttributeInstance healthAttribute = phantom.getAttribute(Attribute.MAX_HEALTH);
        if (healthAttribute != null) {
            healthAttribute.setBaseValue(40.0); 
            phantom.setHealth(40.0);
        }
        
        // Más velocidad
    AttributeInstance speedAttribute = phantom.getAttribute(Attribute.MOVEMENT_SPEED);
        if (speedAttribute != null) {
            speedAttribute.setBaseValue(0.35); 
        }
        
        // Más daño
    AttributeInstance damageAttribute = phantom.getAttribute(Attribute.ATTACK_DAMAGE);
        if (damageAttribute != null) {
            damageAttribute.setBaseValue(5.0); 
        }
        
        // --- 3. Poner la Cabeza del Jugador (Custom Skin) ---
        ItemStack playerHead = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta meta = (SkullMeta) playerHead.getItemMeta();
        
        if (meta != null) {
            meta.setOwningPlayer(originalPlayer);
            meta.setDisplayName("§4Cabeza fantasma de §c" + originalPlayer.getName());
            playerHead.setItemMeta(meta);
        }
        
        phantom.getEquipment().setHelmet(playerHead);
        phantom.getEquipment().setHelmetDropChance(0.0f); 

        // --- 4. Metadatos (Para reconocerlo) ---
        phantom.setMetadata(PHANTOM_KEY, new FixedMetadataValue(plugin, true));

        // retornamos el zombie creado para que el invocador pueda registrarle loot
        return phantom;
    }
    
    // Método de utilidad para identificar al fantasma
    public static boolean isPhantom(LivingEntity entity) {
        return entity.hasMetadata(PHANTOM_KEY);
    }
}