package com.andrestube.phantoms;

import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

import org.bukkit.entity.Entity;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

public class PhantomPlugin extends JavaPlugin {

    // Map que guarda, por UUID de la entidad phantom, la lista de items que debía soltar
    private final Map<UUID, List<ItemStack>> phantomLoot = new ConcurrentHashMap<>();

    @Override
    public void onEnable() {
        // Registramos el listener que detecta la muerte
        getServer().getPluginManager().registerEvents(new PhantomListener(this), this);

        getLogger().info("¡Player Phantoms activado! Morir nunca fue tan aterrador.");
    }

    @Override
    public void onDisable() {
        getLogger().info("Player Phantoms desactivado. El mundo está a salvo... por ahora.");
        phantomLoot.clear();
    }

    // Registro del loot asociado a un phantom
    public void registerPhantomLoot(Entity phantom, List<ItemStack> loot) {
        if (phantom == null || loot == null) return;
        phantomLoot.put(phantom.getUniqueId(), loot);
    }

    // Recupera y elimina el loot asociado (pop)
    public List<ItemStack> popPhantomLoot(UUID phantomUuid) {
        if (phantomUuid == null) return null;
        return phantomLoot.remove(phantomUuid);
    }

}